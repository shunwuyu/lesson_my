import Home from '../pages/Home.vue' // 页面级别组件 
import About from '../pages/About.vue'
import { 
    createWebHashHistory,  // 前端路由的形式hash history api
    // createWebHistory
    createRouter // spa   路由实例  前端路由对象 
} from 'vue-router'

const routes = [
    // 扩展性很好， 
    {
        path: '/',
        name: 'Home',
        component: Home
    },
    {
        path: '/about',
        name: 'About',
        component: About
    }
]

const router = createRouter({
    // 配置前端路由  
    history: createWebHashHistory(),
    routes
})

export default router 